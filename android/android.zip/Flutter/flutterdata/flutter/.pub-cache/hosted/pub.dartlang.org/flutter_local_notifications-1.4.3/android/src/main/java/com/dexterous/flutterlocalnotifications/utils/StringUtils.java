package com.dexterous.flutterlocalnotifications.utils;

public class StringUtils {
    public static Boolean isNullOrEmpty(String string){
        return string == null || string.isEmpty();
    }
}

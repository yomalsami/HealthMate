package com.example.cliniccare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
